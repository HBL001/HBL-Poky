# Kernel patches and out-of-tree driver staging
FILESEXTRAPATHS:prepend := "${THISDIR}/files:"

# 1) Kernel configuration fragment
SRC_URI += "file://extra-configs.cfg"
KERNEL_CONFIG_FRAGMENTS += "extra-configs.cfg"

# 2) Kernel patches (Kconfig/Makefile wiring + DTS additions)
SRC_URI += "file://0001-add-Kconfig-Makefile.patch"
SRC_URI += "file://0002-device-tree-additions.patch"

# 3) Driver source drops (unpacked into WORKDIR)
SRC_URI += "\
    file://ft800-driver/ft800.c \
    file://ft800-driver/ft800.h \
    file://ft800-driver/ft800_ioctl.c \
    file://ft800-driver/Kconfig \
    file://ft800-driver/Makefile \
    file://ds1302-gpio-driver/rtc-ds1302-gpio.c \
    file://ds1302-gpio-driver/Kconfig \
    file://ds1302-gpio-driver/Makefile \
"

do_patch:append() {
    bbnote "Staging FT800 driver sources into ${S}/drivers/ft800-driver"
    rm -rf "${S}/drivers/ft800-driver"
    install -d "${S}/drivers/ft800-driver"
    install -m 0644 "${WORKDIR}/ft800-driver/ft800.c"       "${S}/drivers/ft800-driver/ft800.c"
    install -m 0644 "${WORKDIR}/ft800-driver/ft800.h"       "${S}/drivers/ft800-driver/ft800.h"
    install -m 0644 "${WORKDIR}/ft800-driver/ft800_ioctl.c" "${S}/drivers/ft800-driver/ft800_ioctl.c"
    install -m 0644 "${WORKDIR}/ft800-driver/Kconfig"       "${S}/drivers/ft800-driver/Kconfig"
    install -m 0644 "${WORKDIR}/ft800-driver/Makefile"      "${S}/drivers/ft800-driver/Makefile"

    bbnote "Staging DS1302 GPIO RTC driver sources into ${S}/drivers/ds1302-gpio-driver"
    rm -rf "${S}/drivers/ds1302-gpio-driver"
    install -d "${S}/drivers/ds1302-gpio-driver"
    install -m 0644 "${WORKDIR}/ds1302-gpio-driver/rtc-ds1302-gpio.c" "${S}/drivers/ds1302-gpio-driver/rtc-ds1302-gpio.c"
    install -m 0644 "${WORKDIR}/ds1302-gpio-driver/Kconfig"          "${S}/drivers/ds1302-gpio-driver/Kconfig"
    install -m 0644 "${WORKDIR}/ds1302-gpio-driver/Makefile"         "${S}/drivers/ds1302-gpio-driver/Makefile"
}
